package com.javacode.springboot.cruddemo.rest;

import com.javacode.springboot.cruddemo.entity.Student;
import com.javacode.springboot.cruddemo.exception.StudentNotFoundException;
import com.javacode.springboot.cruddemo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentRestController {

    private StudentService studentService;

    @Autowired
    public StudentRestController(StudentService studentService){
        this.studentService = studentService;
    }

    @GetMapping("/students")
    public List<Student> findAll(){
        return studentService.findAll();
    }

    @GetMapping("/students/{studentId}")
    public Student findById(@PathVariable int studentId){
        Student student = studentService.findById(studentId);
        if(student == null){
           throw new StudentNotFoundException("Student Id not found: " +studentId);
        }
        return student;
    }

    @PostMapping("/students")
    public Student createStudent(@RequestBody Student student){

        student.setId(0);
        Student dbStudent = studentService.save(student);
        return dbStudent;

    }

    @PutMapping("/students/{studentId}")
    public Student updateStudent(@PathVariable int studentId, @RequestBody Student student){
        Student students = studentService.findById(studentId);
        if(students == null){
            throw new StudentNotFoundException("Student id not found - " +studentId);
        }
        students.setFirstName(student.getFirstName());
        students.setLastName(student.getLastName());
        students.setEmail(student.getEmail());
        studentService.save(students);
        return students;
    }

    @DeleteMapping("/students/{studentId}")
    public String deleteStudent(@PathVariable int studentId){
        Student student = studentService.findById(studentId);
        if(student==null){
            throw new StudentNotFoundException("Student Id not found: " +studentId);
        }
        studentService.deleteById(studentId);
        return "Deleted student by Id - " +studentId;
    }
}
