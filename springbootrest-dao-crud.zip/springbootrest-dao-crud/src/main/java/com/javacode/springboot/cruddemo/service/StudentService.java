package com.javacode.springboot.cruddemo.service;

import com.javacode.springboot.cruddemo.entity.Student;

import java.util.List;

public interface StudentService {

    List<Student> findAll();
    Student findById(int id);
    Student save(Student student);

    void deleteById(int id);
}
