package com.javacode.springboot.cruddemo.dao;

import com.javacode.springboot.cruddemo.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentDaoImpl implements StudentDao{

    private EntityManager entityManager;

    @Autowired
    public StudentDaoImpl(EntityManager entityManager){
        this.entityManager = entityManager;
    }

    @Override
    public List<Student> findAll() {

        TypedQuery<Student> typedQuery = entityManager.createQuery("from Student", Student.class);
        List<Student> dbStudent = typedQuery.getResultList();
        return dbStudent;
    }

    @Override
    public Student findById(int id) {
        Student student = entityManager.find(Student.class,id);
        return student;
    }

    @Override
    public Student save(Student student) {

        Student dbStudent = entityManager.merge(student);
        return dbStudent;
    }

    @Override
    public void deleteById(int id) {
        Student student = entityManager.find(Student.class, id);
        entityManager.remove(student);
    }
}
