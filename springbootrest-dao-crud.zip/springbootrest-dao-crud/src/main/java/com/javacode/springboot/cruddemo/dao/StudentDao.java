package com.javacode.springboot.cruddemo.dao;

import com.javacode.springboot.cruddemo.entity.Student;

import java.util.List;

public interface StudentDao {

    List<Student> findAll();
    Student findById(int id);

    Student save(Student student);

    void deleteById(int id);
}
