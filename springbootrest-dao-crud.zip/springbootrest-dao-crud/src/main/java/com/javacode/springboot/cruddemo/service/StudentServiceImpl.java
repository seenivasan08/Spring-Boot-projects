package com.javacode.springboot.cruddemo.service;

import com.javacode.springboot.cruddemo.dao.StudentDao;
import com.javacode.springboot.cruddemo.entity.Student;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService{

    private StudentDao studentDao;

    @Autowired
    public StudentServiceImpl(StudentDao studentDao){
        this.studentDao = studentDao;
    }

    @Override
    public List<Student> findAll() {

        return studentDao.findAll();
    }

    @Override
    public Student findById(int id) {

        return studentDao.findById(id);
    }

    @Transactional
    @Override
    public Student save(Student student) {

        Student studentdb  = studentDao.save(student);
        return studentdb;
    }

    @Transactional
    @Override
    public void deleteById(int id) {
        studentDao.deleteById(id);
    }


}
