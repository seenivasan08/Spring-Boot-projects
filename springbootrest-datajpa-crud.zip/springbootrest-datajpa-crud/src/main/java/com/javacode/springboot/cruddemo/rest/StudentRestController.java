package com.javacode.springboot.cruddemo.rest;

import com.javacode.springboot.cruddemo.entity.Student;
import com.javacode.springboot.cruddemo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentRestController {

    private StudentService studentService;

    @Autowired
    public StudentRestController(StudentService studentService){
        this.studentService = studentService;
    }
    @GetMapping("/students")
    public List<Student> getAllStudent(){
        return studentService.findAll();
    }

    @GetMapping("/students/{studentId}")
    public Student getStudent(@PathVariable int studentId){
        return studentService.findById(studentId);
    }

    @PostMapping("/students")
    public Student createStudent(@RequestBody Student student){
        student.setId(0);
        return studentService.save(student);
    }

    @PutMapping("/students/{studentId}")
    public Student updateStudent(@PathVariable int studentId, @RequestBody Student student){
        //Check whether Student details are exist or not
        Student theStudent =studentService.findById(studentId);
        theStudent.setFirstName(student.getFirstName());
        theStudent.setLastName(student.getLastName());
        theStudent.setEmail(student.getEmail());
        //Updating student details
        studentService.save(theStudent);
        //Return student details after updated
        return theStudent;
    }

    @DeleteMapping("/students/{studentId}")
    public String deleteStudent(@PathVariable int studentId){

        studentService.findById(studentId);
        studentService.deleteById(studentId);
        return "Deleted Student details by student Id - " +studentId;
    }

    @DeleteMapping("/students")
    public String deleteAllStudent(){
        studentService.deleteAll();
        return "Deleted All Students details";
    }
}
