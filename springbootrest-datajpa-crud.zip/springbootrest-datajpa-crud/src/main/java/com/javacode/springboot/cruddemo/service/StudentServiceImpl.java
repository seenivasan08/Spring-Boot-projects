package com.javacode.springboot.cruddemo.service;

import com.javacode.springboot.cruddemo.dao.StudentRespository;
import com.javacode.springboot.cruddemo.entity.Student;
import com.javacode.springboot.cruddemo.exception.StudentNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService{

    private StudentRespository studentRespository;

    @Autowired
    public StudentServiceImpl(StudentRespository studentRespository){
        this.studentRespository = studentRespository;
    }
    @Override
    public List<Student> findAll() {
        return studentRespository.findAll();
    }

    @Override
    public Student findById(int id) {
        Optional<Student> result = studentRespository.findById(id);
        Student student = null;
        if(result.isPresent()){
            student = result.get();
        }
        else{
            throw new StudentNotFoundException("Did not find Student Id - " +id);
        }
        return student;
    }

    @Override
    public Student save(Student student) {

        return studentRespository.save(student);
    }

    @Override
    public void deleteById(int id) {
        studentRespository.deleteById(id);
    }

    @Override
    public void deleteAll() {
        studentRespository.deleteAll();
    }
}
