package com.javacode.springboot.cruddemo.dao;

import com.javacode.springboot.cruddemo.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRespository extends JpaRepository<Student, Integer> {

}
